This is top level generated with SystemBuilder
Il faut ensuite cabler en modifiant le DE10_LITE.v